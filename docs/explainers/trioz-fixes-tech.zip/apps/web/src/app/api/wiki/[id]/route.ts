import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { checkBan } from "@/lib/banCheck";
import { sanitizeText } from "@/lib/sanitize";
import prisma from "@/lib/prisma";

// Роли группы, у которых всегда есть права модерации раздела
const MANAGE_ROLES = ["OWNER", "ADMIN", "MODERATOR"];

// Кто может редактировать базу знаний (см. комментарий в /api/wiki/route.ts):
//  - postAccess "ADMIN" -> только владелец/админ группы;
//  - postAccess "MOD"   -> владелец/админ + модераторы;
//  - postAccess "ALL"   -> все участники группы;
//  - администратор сайта — всегда.
function canEditWiki(membershipRole: string, postAccess?: string | null, userRole?: string | null): boolean {
  if (userRole === "ADMIN") return true;
  if (membershipRole === "OWNER" || membershipRole === "ADMIN") return true;
  if (membershipRole === "MODERATOR") return postAccess !== "ADMIN";
  return postAccess === "ALL";
}

async function canReadChannel(
  channel: { isRestricted: boolean; allowedRoles: { roleId: string }[] },
  membership: { id: string; role: string },
): Promise<boolean> {
  if (!channel.isRestricted) return true;
  if (MANAGE_ROLES.includes(membership.role)) return true;
  if (!channel.allowedRoles || channel.allowedRoles.length === 0) return true;
  const tags = await prisma.groupMemberRole.findMany({
    where: { memberId: membership.id },
    select: { roleId: true },
  });
  const userRoleIds = new Set(tags.map((t) => t.roleId));
  return channel.allowedRoles.some((a) => userRoleIds.has(a.roleId));
}

async function loadCtx(articleId: string, userId: string) {
  const article = await prisma.wikiArticle.findUnique({
    where: { id: articleId },
    include: {
      channel: { select: { groupId: true, postAccess: true, isRestricted: true, allowedRoles: { select: { roleId: true } } } },
      updatedBy: { select: { id: true, name: true, username: true } },
    },
  });
  if (!article) return { error: NextResponse.json({ error: "Not found" }, { status: 404 }) };
  const membership = await prisma.groupMember.findUnique({
    where: { userId_groupId: { userId, groupId: article.channel.groupId } },
  });
  if (!membership) return { error: NextResponse.json({ error: "Forbidden" }, { status: 403 }) };
  if (!(await canReadChannel(article.channel, membership))) {
    return { error: NextResponse.json({ error: "Нет доступа к этому разделу" }, { status: 403 }) };
  }
  return { article, membership };
}

// GET /api/wiki/[id]
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const ctx = await loadCtx(id, session.user.id);
  if (ctx.error) return ctx.error;
  const canEdit = canEditWiki(ctx.membership!.role, ctx.article!.channel.postAccess, session.user.role);
  return NextResponse.json({ article: ctx.article, canEdit });
}

// PATCH /api/wiki/[id]  { title?, content?, category?, term? }
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const banned = await checkBan(session.user.id);
  if (banned) return banned;

  const { id } = await params;
  const ctx = await loadCtx(id, session.user.id);
  if (ctx.error) return ctx.error;
  if (!canEditWiki(ctx.membership!.role, ctx.article!.channel.postAccess, session.user.role)) {
    return NextResponse.json({ error: "Нет прав на редактирование статей в этом разделе" }, { status: 403 });
  }

  const { title, content, category, term } = await req.json();
  const data: { title?: string; content?: string; category?: string; term?: string | null; updatedById: string } = { updatedById: session.user.id };
  if (typeof title === "string" && title.trim()) data.title = sanitizeText(title).slice(0, 200);
  if (typeof category === "string") data.category = category.slice(0, 80);
  if (typeof term === "string") data.term = term.trim() ? term.slice(0, 120) : null;

  // При изменении текста сохраняем предыдущую версию в историю правок
  if (typeof content === "string" && content !== ctx.article!.content) {
    if (content.length > 50000) return NextResponse.json({ error: "Слишком длинный текст статьи (макс. 50 000 символов)" }, { status: 400 });
    await prisma.wikiRevision.create({
      data: { articleId: id, content: ctx.article!.content, editorId: ctx.article!.updatedById },
    });
    data.content = content;
  }

  const updated = await prisma.wikiArticle.update({ where: { id }, data });
  return NextResponse.json({ article: updated });
}

// DELETE /api/wiki/[id]
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const ctx = await loadCtx(id, session.user.id);
  if (ctx.error) return ctx.error;
  if (!canEditWiki(ctx.membership!.role, ctx.article!.channel.postAccess, session.user.role)) {
    return NextResponse.json({ error: "Нет прав на удаление статей в этом разделе" }, { status: 403 });
  }
  await prisma.wikiArticle.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}

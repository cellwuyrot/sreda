import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { rateLimit } from "@/lib/rateLimit";
import { checkBan } from "@/lib/banCheck";
import { sanitizeText } from "@/lib/sanitize";
import prisma from "@/lib/prisma";

function slugify(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9а-яё]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "article";
}

// Роли группы, у которых всегда есть права модерации раздела
const MANAGE_ROLES = ["OWNER", "ADMIN", "MODERATOR"];

// Кто может редактировать базу знаний (создавать/править/удалять статьи):
//  - postAccess "ADMIN" -> только владелец/админ группы;
//  - postAccess "MOD"   -> владелец/админ + модераторы (режим «создатель + модератор»);
//  - postAccess "ALL"   -> все участники группы;
//  - администратор сайта — всегда.
// Настраивается через шестерёнку в шапке модуля (ModuleSettingsModal).
function canEditWiki(membershipRole: string, postAccess?: string | null, userRole?: string | null): boolean {
  if (userRole === "ADMIN") return true;
  if (membershipRole === "OWNER" || membershipRole === "ADMIN") return true;
  if (membershipRole === "MODERATOR") return postAccess !== "ADMIN";
  return postAccess === "ALL";
}

// Кто может читать раздел: все участники, либо (если включено ограничение
// «Только выбранные роли») только участники с одной из разрешённых ролей.
// Владелец, админ и модераторы группы видят раздел всегда.
async function canReadChannel(
  channel: { isRestricted: boolean; allowedRoles: { roleId: string }[] },
  membership: { id: string; role: string },
): Promise<boolean> {
  if (!channel.isRestricted) return true;
  if (MANAGE_ROLES.includes(membership.role)) return true;
  if (!channel.allowedRoles || channel.allowedRoles.length === 0) return true;
  const tags = await prisma.groupMemberRole.findMany({
    where: { memberId: membership.id },
    select: { roleId: true },
  });
  const userRoleIds = new Set(tags.map((t) => t.roleId));
  return channel.allowedRoles.some((a) => userRoleIds.has(a.roleId));
}

// GET /api/wiki?channelId=...&q=...&category=...
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const channelId = searchParams.get("channelId");
  const q = searchParams.get("q")?.trim();
  const category = searchParams.get("category")?.trim();
  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 });

  const channel = await prisma.channel.findUnique({
    where: { id: channelId },
    select: { groupId: true, postAccess: true, isRestricted: true, allowedRoles: { select: { roleId: true } } },
  });
  if (!channel) return NextResponse.json({ error: "Channel not found" }, { status: 404 });

  const membership = await prisma.groupMember.findUnique({
    where: { userId_groupId: { userId: session.user.id, groupId: channel.groupId } },
  });
  if (!membership) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  if (!(await canReadChannel(channel, membership))) {
    return NextResponse.json({ error: "Нет доступа к этому разделу" }, { status: 403 });
  }

  const where: { channelId: string; category?: string; OR?: unknown[] } = { channelId };
  if (category) where.category = category;
  if (q) where.OR = [
    { title: { contains: q, mode: "insensitive" } },
    { content: { contains: q, mode: "insensitive" } },
  ];

  const articles = await prisma.wikiArticle.findMany({
    where: where as never,
    select: { id: true, title: true, term: true, slug: true, category: true, updatedAt: true,
      updatedBy: { select: { id: true, name: true, username: true } } },
    orderBy: [{ category: "asc" }, { title: "asc" }],
    take: 500,
  });

  const canEdit = canEditWiki(membership.role, channel.postAccess, session.user.role);
  return NextResponse.json({ articles, canEdit });
}

// POST /api/wiki  { channelId, title, content, category, term }
export async function POST(req: NextRequest) {
  const limited = await rateLimit(req, "wiki", { limit: 30, windowMs: 60 * 1000 });
  if (limited) return limited;

  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const banned = await checkBan(session.user.id);
  if (banned) return banned;

  const { channelId, title, content, category, term } = await req.json();
  if (!channelId || !title?.trim()) return NextResponse.json({ error: "Заполните заголовок статьи" }, { status: 400 });
  if (title.length > 200) return NextResponse.json({ error: "Слишком длинный заголовок (макс. 200 символов)" }, { status: 400 });
  if (typeof content === "string" && content.length > 50000) return NextResponse.json({ error: "Слишком длинный текст статьи (макс. 50 000 символов)" }, { status: 400 });

  const channel = await prisma.channel.findUnique({
    where: { id: channelId },
    select: { groupId: true, type: true, postAccess: true, isRestricted: true, allowedRoles: { select: { roleId: true } } },
  });
  if (!channel) return NextResponse.json({ error: "Channel not found" }, { status: 404 });
  // ФИКС БАГА: раньше здесь была жёсткая проверка channel.type !== "WIKI" -> 400 "Not a Wiki channel".
  // Разделы-блоки создаются с типом "NEWS"/"TEXT", поэтому создание статей и терминов
  // словаря в них падало, а интерфейс не показывал ошибку. Теперь запрещены только
  // заведомо неподходящие типы каналов.
  if (channel.type === "VOICE" || channel.type === "CATEGORY") {
    return NextResponse.json({ error: "Этот канал не поддерживает базу знаний" }, { status: 400 });
  }

  const membership = await prisma.groupMember.findUnique({
    where: { userId_groupId: { userId: session.user.id, groupId: channel.groupId } },
  });
  if (!membership) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  if (!(await canReadChannel(channel, membership))) {
    return NextResponse.json({ error: "Нет доступа к этому разделу" }, { status: 403 });
  }
  if (!canEditWiki(membership.role, channel.postAccess, session.user.role)) {
    return NextResponse.json({ error: "Нет прав на создание статей в этом разделе" }, { status: 403 });
  }

  let slug = slugify(title);
  const existing = await prisma.wikiArticle.findUnique({ where: { channelId_slug: { channelId, slug } } });
  if (existing) slug = slug + "-" + Date.now().toString(36);

  const article = await prisma.wikiArticle.create({
    data: {
      channelId,
      title: sanitizeText(title),
      slug,
      content: typeof content === "string" ? content : "",
      category: typeof category === "string" ? category.slice(0, 80) : "",
      term: typeof term === "string" && term.trim() ? term.slice(0, 120) : null,
      updatedById: session.user.id,
    },
  });

  return NextResponse.json({ article });
}

"use client";

import { useState, useEffect, useCallback } from "react";

/*
  Настройки рабочего модуля (раздела) группы: просмотр и редактирование.

  Открывается по шестерёнке в шапке модуля (задачи, база знаний и т.д.).
  Кнопка показывается только при canModerate; сервер дополнительно
  проверяет права в PUT /api/channels/[id].

  Хранение — существующие поля канала, миграции БД не требуются:
   - postAccess: "ADMIN" | "MOD" | "ALL"  -> кто может редактировать;
   - isRestricted + список ролей        -> кто может читать (все или выбранные роли).
*/

type GroupRole = { id: string; name: string; color: string };

type ChannelInfo = {
  id: string;
  name: string;
  groupId: string;
  type: string;
  postAccess: string;
  isRestricted: boolean;
  roleIds?: string[];
};

const EDIT_OPTIONS: { value: "MOD" | "ADMIN" | "ALL"; label: string; hint: string }[] = [
  { value: "MOD", label: "Создатель + модераторы", hint: "рекомендуемый режим" },
  { value: "ADMIN", label: "Только создатель и админ", hint: "модераторы — только чтение" },
  { value: "ALL", label: "Все участники", hint: "редактировать может каждый" },
];

/* Та же шестерёнка, что уже используется в настройках блоков (SectionsPanel) */
export function GearIcon({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

/* Кнопка-шестерёнка для шапки любого рабочего модуля */
export function ModuleSettingsButton({ channelId, className }: { channelId: string; className?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        type="button"
        onClick={(e) => { e.stopPropagation(); setOpen(true); }}
        className={className || "w-7 h-7 flex items-center justify-center rounded-md text-neutral-400 hover:text-neutral-700 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-white/10 transition-all flex-none"}
        title="Настройки раздела: просмотр и редактирование"
        aria-label="Настройки раздела"
      >
        <GearIcon size={16} />
      </button>
      {open && <ModuleSettingsModal channelId={channelId} onClose={() => setOpen(false)} />}
    </>
  );
}

export default function ModuleSettingsModal({ channelId, onClose }: { channelId: string; onClose: () => void }) {
  const [channel, setChannel] = useState<ChannelInfo | null>(null);
  const [roles, setRoles] = useState<GroupRole[]>([]);
  const [postAccess, setPostAccess] = useState<"MOD" | "ADMIN" | "ALL">("MOD");
  const [restrictedRead, setRestrictedRead] = useState(false);
  const [roleIds, setRoleIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/channels/${channelId}`);
      if (!res.ok) throw new Error("Не удалось загрузить настройки раздела");
      const ch: ChannelInfo = await res.json();
      setChannel(ch);
      setPostAccess(ch.postAccess === "ADMIN" || ch.postAccess === "MOD" ? ch.postAccess : "ALL");
      setRestrictedRead(!!ch.isRestricted);
      setRoleIds(new Set(ch.roleIds || []));
      if (ch.groupId) {
        const rr = await fetch(`/api/groups/${ch.groupId}/roles`);
        if (rr.ok) {
          const d = await rr.json();
          setRoles(Array.isArray(d) ? d : (Array.isArray(d?.roles) ? d.roles : []));
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка загрузки");
    } finally {
      setLoading(false);
    }
  }, [channelId]);

  useEffect(() => { load(); }, [load]);

  const toggleRole = (id: string) => {
    setRoleIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const save = async () => {
    setSaving(true);
    setError("");
    const res = await fetch(`/api/channels/${channelId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        postAccess,
        isRestricted: restrictedRead,
        roleIds: restrictedRead ? Array.from(roleIds) : [],
      }),
    }).catch(() => null);
    setSaving(false);
    if (!res || !res.ok) {
      setError("Не удалось сохранить настройки");
      return;
    }
    onClose();
  };

  const cardCls = (active: boolean) =>
    `flex items-center gap-3 p-2.5 rounded-xl border cursor-pointer transition-colors ${active ? "border-violet-500 dark:border-cyan-400 bg-violet-500/5 dark:bg-cyan-400/5" : "border-neutral-200 dark:border-white/10 hover:bg-neutral-50 dark:hover:bg-white/5"}`;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-4" onClick={onClose} role="dialog" aria-modal="true" aria-label="Настройки раздела">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto bg-white dark:bg-neutral-900 rounded-2xl p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 mb-1 text-neutral-900 dark:text-white">
          <GearIcon size={18} />
          <h3 className="text-lg font-semibold">Настройки раздела{channel ? ` «${channel.name}»` : ""}</h3>
        </div>
        <p className="text-xs text-neutral-500 dark:text-neutral-400 mb-4">
          Управление просмотром и редактированием этого рабочего модуля группы.
        </p>

        {loading ? (
          <p className="text-sm text-neutral-400 py-4 text-center">Загрузка…</p>
        ) : (
          <>
            <div className="mb-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-neutral-400 mb-1.5">Кто может редактировать</p>
              <div className="space-y-1.5">
                {EDIT_OPTIONS.map((opt) => (
                  <label key={opt.value} className={cardCls(postAccess === opt.value)}>
                    <input
                      type="radio"
                      name="module-edit-access"
                      value={opt.value}
                      checked={postAccess === opt.value}
                      onChange={() => setPostAccess(opt.value)}
                      className="accent-violet-600 dark:accent-cyan-400"
                    />
                    <span className="text-sm font-medium text-neutral-800 dark:text-neutral-200">{opt.label}</span>
                    <span className="text-[11px] text-neutral-400">· {opt.hint}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="mb-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-neutral-400 mb-1.5">Кто может читать</p>
              <div className="space-y-1.5">
                <label className={cardCls(!restrictedRead)}>
                  <input type="radio" name="module-read-access" checked={!restrictedRead} onChange={() => setRestrictedRead(false)} className="accent-violet-600 dark:accent-cyan-400" />
                  <span className="text-sm font-medium text-neutral-800 dark:text-neutral-200">Все участники группы</span>
                </label>
                <label className={cardCls(restrictedRead)}>
                  <input type="radio" name="module-read-access" checked={restrictedRead} onChange={() => setRestrictedRead(true)} className="accent-violet-600 dark:accent-cyan-400" />
                  <span className="text-sm font-medium text-neutral-800 dark:text-neutral-200">Только выбранные роли</span>
                </label>
              </div>

              {restrictedRead && (
                <div className="mt-2 rounded-xl border border-neutral-200 dark:border-white/10 p-2 max-h-44 overflow-y-auto space-y-0.5">
                  {roles.length === 0 ? (
                    <p className="text-xs text-neutral-400 px-1.5 py-1">
                      В группе пока нет ролей. Создайте роли в настройках группы, затем выберите их здесь.
                    </p>
                  ) : (
                    roles.map((role) => (
                      <label key={role.id} className="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-neutral-50 dark:hover:bg-white/5 cursor-pointer text-sm">
                        <input
                          type="checkbox"
                          checked={roleIds.has(role.id)}
                          onChange={() => toggleRole(role.id)}
                          className="accent-violet-600 dark:accent-cyan-400"
                        />
                        <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={ { backgroundColor: role.color } } />
                        <span className="text-neutral-800 dark:text-neutral-200 truncate">{role.name}</span>
                      </label>
                    ))
                  )}
                  <p className="text-[11px] text-neutral-400 px-1.5 pt-1">
                    Владелец, админ и модераторы группы видят раздел всегда. Если роли не выбраны — раздел видят все.
                  </p>
                </div>
              )}
            </div>
          </>
        )}

        {error && <p className="text-xs text-red-500 mb-2">{error}</p>}

        <div className="flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800">Отмена</button>
          <button onClick={save} disabled={saving || loading} className="px-4 py-2 rounded-lg text-sm font-medium bg-violet-600 hover:bg-violet-700 dark:bg-cyan-500 dark:hover:bg-cyan-400 text-white disabled:opacity-50">
            {saving ? "Сохранение…" : "Сохранить"}
          </button>
        </div>
      </div>
    </div>
  );
}

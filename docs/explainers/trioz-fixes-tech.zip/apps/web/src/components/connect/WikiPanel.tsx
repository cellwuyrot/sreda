"use client";

import { useState, useEffect, useCallback } from "react";
import { ModuleSettingsButton } from "./ModuleSettingsModal";

type WikiAuthor = { id: string; name: string; username: string };
type WikiListItem = { id: string; title: string; term?: string | null; slug: string; category: string; updatedAt: string; updatedBy: WikiAuthor | null };
type WikiArticleFull = WikiListItem & { content: string };
type WikiRevisionItem = { id: string; content: string; createdAt: string; editor: WikiAuthor | null };

export default function WikiPanel({ channelId, channelName, canModerate, onBack }: { channelId: string; channelName: string; currentUserId?: string; canModerate?: boolean; onBack?: () => void }) {
  const [articles, setArticles] = useState<WikiListItem[]>([]);
  const [canEdit, setCanEdit] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [current, setCurrent] = useState<WikiArticleFull | null>(null);
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState({ title: "", term: "", category: "", content: "" });
  const [revisions, setRevisions] = useState<WikiRevisionItem[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [mode, setMode] = useState<"articles" | "glossary">("articles");

  const fetchList = useCallback(async () => {
    const params = new URLSearchParams({ channelId });
    if (query.trim()) params.set("q", query.trim());
    const res = await fetch("/api/wiki?" + params.toString());
    if (!res.ok) return;
    const data = await res.json();
    setArticles(data.articles || []);
    setCanEdit(!!data.canEdit);
  }, [channelId, query]);

  useEffect(() => { fetchList(); }, [fetchList]);

  const openArticle = useCallback(async (id: string) => {
    setSelectedId(id); setEditing(false); setRevisions(null); setLoading(true);
    const res = await fetch("/api/wiki/" + id);
    setLoading(false);
    if (!res.ok) return;
    const data = await res.json();
    setCurrent(data.article);
    setCanEdit(!!data.canEdit);
  }, []);

  const startCreate = () => { setSelectedId(null); setCurrent(null); setRevisions(null); setEditing(true); setError(""); setDraft({ title: "", term: "", category: "", content: "" }); };
  const startEdit = () => { if (!current) return; setEditing(true); setError(""); setDraft({ title: current.title, term: current.term || "", category: current.category, content: current.content }); };

  const save = async () => {
    if (!draft.title.trim()) return;
    setLoading(true);
    setError("");
    let res;
    if (selectedId) {
      res = await fetch("/api/wiki/" + selectedId, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(draft) });
    } else {
      res = await fetch("/api/wiki", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ channelId, ...draft }) });
    }
    setLoading(false);
    if (!res.ok) {
      // ФИКС БАГА: раньше ошибка сервера молча проглатывалась (if (!res.ok) return;),
      // из-за чего казалось, что создание статей и словаря просто не работает.
      const data = await res.json().catch(() => ({} as { error?: string }));
      setError(data.error || "Не удалось сохранить статью. Попробуйте ещё раз.");
      return;
    }
    const data = await res.json();
    setEditing(false);
    await fetchList();
    if (data.article?.id) await openArticle(data.article.id);
  };

  const remove = async () => {
    if (!selectedId || !confirm("Удалить статью?")) return;
    setError("");
    const res = await fetch("/api/wiki/" + selectedId, { method: "DELETE" });
    if (!res.ok) {
      const data = await res.json().catch(() => ({} as { error?: string }));
      setError(data.error || "Не удалось удалить статью");
      return;
    }
    setSelectedId(null); setCurrent(null); setEditing(false);
    await fetchList();
  };

  const loadRevisions = async () => {
    if (!selectedId) return;
    const res = await fetch("/api/wiki/" + selectedId + "/revisions");
    if (!res.ok) return;
    const data = await res.json();
    setRevisions(data.revisions || []);
  };

  const categories = Array.from(new Set(articles.map(a => a.category).filter(Boolean))).sort();
  const grouped = (cat: string) => articles.filter(a => (a.category || "") === cat);
  const uncategorized = articles.filter(a => !a.category);

  return (
    <div className="flex h-full min-h-0">
      <aside className="w-64 flex-shrink-0 border-r border-neutral-200 dark:border-white/10 flex flex-col min-h-0">
        <div className="p-3 border-b border-neutral-200 dark:border-white/10">
          {onBack && <button onClick={onBack} className="md:hidden text-sm text-neutral-500 mb-2">← Назад</button>}
          <div className="flex items-center gap-2 font-semibold text-neutral-800 dark:text-gray-100">
            <span className="flex-1 min-w-0 truncate">📚 {channelName}</span>
            {canModerate && <ModuleSettingsButton channelId={channelId} />}
          </div>
          <div className="flex items-center gap-1 rounded-lg bg-neutral-100 dark:bg-white/5 p-0.5 text-xs">
            <button onClick={() => setMode("articles")} className={`flex-1 px-2 py-1 rounded-md ${mode === "articles" ? "bg-emerald-500 text-white" : "text-neutral-500 dark:text-gray-400"}`}>Статьи</button>
            <button onClick={() => setMode("glossary")} className={`flex-1 px-2 py-1 rounded-md ${mode === "glossary" ? "bg-emerald-500 text-white" : "text-neutral-500 dark:text-gray-400"}`}>Словарь</button>
          </div>
          <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Поиск…"
            className="mt-2 w-full text-sm px-2 py-1.5 rounded-lg bg-neutral-100 dark:bg-white/5 outline-none" />
          {canEdit && <button onClick={startCreate} className="mt-2 w-full text-sm px-2 py-1.5 rounded-lg bg-violet-600 dark:bg-cyan-500 text-white">+ Новая статья</button>}
        </div>
        <nav className="flex-1 overflow-y-auto p-2 space-y-3">
          {categories.map(cat => (
            <div key={cat}>
              <div className="text-xs uppercase tracking-wide text-neutral-400 px-2 mb-1">{cat}</div>
              {grouped(cat).map(a => (
                <button key={a.id} onClick={() => openArticle(a.id)}
                  className={"w-full text-left px-2 py-1.5 rounded-lg text-sm truncate " + (selectedId === a.id ? "bg-neutral-200 dark:bg-white/10" : "hover:bg-neutral-100 dark:hover:bg-white/5")}>{a.title}</button>
              ))}
            </div>
          ))}
          {uncategorized.length > 0 && (
            <div>
              {categories.length > 0 && <div className="text-xs uppercase tracking-wide text-neutral-400 px-2 mb-1">Без категории</div>}
              {uncategorized.map(a => (
                <button key={a.id} onClick={() => openArticle(a.id)}
                  className={"w-full text-left px-2 py-1.5 rounded-lg text-sm truncate " + (selectedId === a.id ? "bg-neutral-200 dark:bg-white/10" : "hover:bg-neutral-100 dark:hover:bg-white/5")}>{a.title}</button>
              ))}
            </div>
          )}
          {articles.length === 0 && <div className="text-sm text-neutral-400 px-2">Статей пока нет.</div>}
        </nav>
      </aside>

      <main className="flex-1 min-w-0 overflow-y-auto p-6">
        {(!editing && mode === "glossary") ? (
          <GlossaryView entries={articles.filter(a => a.term)} query={query} />
        ) : editing ? (
          <div className="max-w-3xl mx-auto space-y-3">
            <input value={draft.title} onChange={e => setDraft({ ...draft, title: e.target.value })} placeholder="Заголовок"
              className="w-full text-2xl font-bold bg-transparent outline-none border-b border-neutral-200 dark:border-white/10 pb-2" />
            <input value={draft.term} onChange={e => setDraft({ ...draft, term: e.target.value })} placeholder="Термин (для режима «Словарь», необязательно)"
              className="w-full text-sm px-3 py-1.5 rounded-lg bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/10 outline-none" />
            <input value={draft.category} onChange={e => setDraft({ ...draft, category: e.target.value })} placeholder="Категория (необязательно)"
              className="w-full text-sm px-2 py-1.5 rounded-lg bg-neutral-100 dark:bg-white/5 outline-none" />
            <textarea value={draft.content} onChange={e => setDraft({ ...draft, content: e.target.value })} placeholder="Текст статьи (Markdown)…"
              className="w-full h-[55vh] text-sm px-3 py-2 rounded-lg bg-neutral-100 dark:bg-white/5 outline-none font-mono resize-none" />
            {error && <p className="text-sm text-red-500">{error}</p>}
            <div className="flex gap-2">
              <button onClick={save} disabled={loading || !draft.title.trim()} className="px-4 py-2 rounded-lg bg-violet-600 dark:bg-cyan-500 text-white text-sm disabled:opacity-50">Сохранить</button>
              <button onClick={() => setEditing(false)} className="px-4 py-2 rounded-lg bg-neutral-200 dark:bg-white/10 text-sm">Отмена</button>
            </div>
          </div>
        ) : current ? (
          <article className="max-w-3xl mx-auto">
            <div className="flex items-start justify-between gap-4">
              <h1 className="text-3xl font-bold text-neutral-900 dark:text-gray-50">{current.title}</h1>
              {canEdit && (
                <div className="flex gap-2 flex-shrink-0">
                  <button onClick={startEdit} className="px-3 py-1.5 rounded-lg bg-neutral-200 dark:bg-white/10 text-sm">Править</button>
                  <button onClick={remove} className="px-3 py-1.5 rounded-lg bg-red-100 dark:bg-red-900/40 text-red-600 text-sm">Удалить</button>
                </div>
              )}
            </div>
            <div className="text-xs text-neutral-400 mt-1 mb-4">
              {current.category && <span className="mr-2">📂 {current.category}</span>}
              {current.updatedBy && <span>ред. {current.updatedBy.name} · </span>}
              {new Date(current.updatedAt).toLocaleString()}
              <button onClick={loadRevisions} className="ml-2 underline hover:text-neutral-600">История</button>
            </div>
            {error && <p className="text-sm text-red-500 mb-3">{error}</p>}
            <div className="prose dark:prose-invert max-w-none whitespace-pre-wrap text-neutral-800 dark:text-gray-200">{current.content || "(пусто)"}</div>
            {revisions && (
              <div className="mt-8 border-t border-neutral-200 dark:border-white/10 pt-4">
                <h3 className="font-semibold mb-2 text-sm">История правок ({revisions.length})</h3>
                <ul className="space-y-2">
                  {revisions.map(r => (
                    <li key={r.id} className="text-xs text-neutral-500">
                      {new Date(r.createdAt).toLocaleString()} {r.editor ? "· " + r.editor.name : ""}
                    </li>
                  ))}
                  {revisions.length === 0 && <li className="text-xs text-neutral-400">Правок ещё не было.</li>}
                </ul>
              </div>
            )}
          </article>
        ) : (
          <div className="h-full flex items-center justify-center text-neutral-400 text-sm">{loading ? "Загрузка…" : "Выберите статью слева"}</div>
        )}
      </main>
    </div>
  );
}

function GlossaryView({ entries, query }: { entries: { id: string; term?: string | null; title: string }[]; query: string }) {
  const [open, setOpen] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);

  const filtered = entries
    .filter(e => (e.term || "").toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => (a.term || "").localeCompare(b.term || "", "ru"));

  const groups: Record<string, typeof filtered> = {};
  for (const e of filtered) {
    const letter = (e.term || "#").charAt(0).toUpperCase();
    (groups[letter] = groups[letter] || []).push(e);
  }
  const letters = Object.keys(groups).sort((a, b) => a.localeCompare(b, "ru"));

  const toggle = async (id: string) => {
    if (open[id] !== undefined) { setOpen(o => { const n = { ...o }; delete n[id]; return n; }); return; }
    setBusy(id);
    try {
      const res = await fetch("/api/wiki/" + id);
      if (res.ok) { const d = await res.json(); setOpen(o => ({ ...o, [id]: (d.article?.content || d.content || "") })); }
    } finally { setBusy(null); }
  };

  if (filtered.length === 0) {
    return <div className="max-w-3xl mx-auto text-center text-neutral-400 mt-12"><div className="text-4xl mb-2">📖</div><p>{query ? "Терминов не найдено" : "Словарь пуст. Создайте статью и заполните поле «Термин»."}</p></div>;
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex flex-wrap gap-1 mb-4 sticky top-0 bg-white dark:bg-neutral-900 py-2">
        {letters.map(l => (<a key={l} href={"#gl-" + l} className="w-7 h-7 flex items-center justify-center rounded text-xs font-semibold bg-neutral-100 dark:bg-white/5 hover:bg-emerald-500 hover:text-white">{l}</a>))}
      </div>
      {letters.map(l => (
        <div key={l} id={"gl-" + l} className="mb-5">
          <div className="text-xs font-bold text-emerald-500 mb-1.5">{l}</div>
          <div className="space-y-1.5">
            {groups[l].map(e => (
              <div key={e.id} className="rounded-lg border border-neutral-200 dark:border-white/10 overflow-hidden">
                <button onClick={() => toggle(e.id)} className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-neutral-50 dark:hover:bg-white/5">
                  <span className="font-semibold">{e.term}</span>
                  <span className="text-neutral-400 text-sm">{busy === e.id ? "…" : (open[e.id] !== undefined ? "−" : "+")}</span>
                </button>
                {open[e.id] !== undefined && (
                  <div className="px-3 pb-3 pt-1 text-sm text-neutral-700 dark:text-gray-300 whitespace-pre-wrap border-t border-neutral-100 dark:border-white/5">{open[e.id] || "(определение пусто)"}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

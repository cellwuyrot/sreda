"use client";

import { useRef, useEffect, useState, useCallback } from "react";
import { createPortal } from "react-dom";
import { motion } from "framer-motion";
import type { ScreenShare } from "@/contexts/VoiceContext";

interface ScreenShareWindowProps {
  /** All active screen shares (own share first, then remotes). */
  shares: ScreenShare[];
  /** Stop the local user's own share. */
  onStopLocal?: () => void;
}

/**
 * Screen-share viewer.
 *
 * Like Discord, shares open as a large centred "stage" that fills most of the
 * app window. When more than one person shares at once, a strip of live
 * thumbnails lets the viewer switch between them. From the stage the user can:
 *   • jump to true fullscreen,
 *   • shrink to a compact, draggable picture-in-picture,
 *   • or minimise to just the title bar.
 *
 * The window is rendered through a portal on `document.body` so a transformed
 * ancestor can never shift its `position: fixed` coordinates off-screen, and
 * every drag is clamped to the viewport so it can't escape the app frame.
 */
export default function ScreenShareWindow({ shares, onStopLocal }: ScreenShareWindowProps) {
  const dragRef = useRef<HTMLDivElement>(null);
  // sm = compact PiP, md = large, lg = theater (near-fullscreen inside the app)
  const [size, setSize] = useState<"sm" | "md" | "lg">("lg");
  const [pos, setPos] = useState({ x: 80, y: 80 });
  // While docked the stage is centred via CSS; the first drag "undocks" it so
  // the user can park it anywhere (picture-in-picture style).
  const [docked, setDocked] = useState(true);
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ mx: 0, my: 0, px: 0, py: 0 });
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  // Which share is shown on the big stage. Falls back to the first share when
  // the selected one goes away (the sharer left or stopped).
  const [activeId, setActiveId] = useState<string | null>(null);

  // Keep the selection valid as shares come and go.
  useEffect(() => {
    if (shares.length === 0) { setActiveId(null); return; }
    if (!activeId || !shares.some(s => s.socketId === activeId)) {
      setActiveId(shares[0].socketId);
    }
  }, [shares, activeId]);

  const active = shares.find(s => s.socketId === activeId) ?? shares[0] ?? null;
  const activeStream = active?.stream ?? null;

  // Callback ref: (re)attach the stream whenever the <video> element mounts or
  // the selected stream changes. This is what fixes the "black screen on
  // fullscreen" bug — toggling fullscreen or un-minimising mounts a *new*
  // <video> element, and a plain effect keyed on the stream would not re-run to
  // set `srcObject` on it. A callback ref always fires on the fresh node.
  const attachVideo = useCallback((el: HTMLVideoElement | null) => {
    if (el && activeStream && el.srcObject !== activeStream) {
      el.srcObject = activeStream;
      el.play().catch(() => {});
    }
  }, [activeStream]);

  // Viewport-relative sizes so the stage scales with the window — a shared
  // screen is legible on a laptop and expansive on a big monitor.
  const sizeClasses = {
    sm: "w-[380px] h-[214px]",
    md: "w-[min(72vw,1000px)] h-[min(62vh,620px)]",
    lg: "w-[min(94vw,1680px)] h-[min(86vh,940px)]",
  };

  // Clamp a candidate top-left position so the window always stays fully inside
  // the viewport (the "app frame").
  const clamp = useCallback((x: number, y: number) => {
    const rect = dragRef.current?.getBoundingClientRect();
    const w = rect?.width ?? 400;
    const h = rect?.height ?? 300;
    const maxX = Math.max(0, window.innerWidth - w);
    const maxY = Math.max(0, window.innerHeight - h);
    return { x: Math.min(Math.max(0, x), maxX), y: Math.min(Math.max(0, y), maxY) };
  }, []);

  // Drag handlers — the first grab "undocks" from the centre, snapping the
  // window's absolute position to where it currently sits so it doesn't jump.
  const onMouseDown = useCallback((e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest("button")) return;
    // Minimised, the window is pinned to the bottom of the screen and can't be
    // dragged — it's just a status/audio bar.
    if (minimized) return;
    let startX = pos.x, startY = pos.y;
    if (docked && dragRef.current) {
      const rect = dragRef.current.getBoundingClientRect();
      startX = rect.left;
      startY = rect.top;
      setPos({ x: startX, y: startY });
      setDocked(false);
    }
    setDragging(true);
    setDragStart({ mx: e.clientX, my: e.clientY, px: startX, py: startY });
  }, [pos, docked, minimized]);

  useEffect(() => {
    if (!dragging) return;
    const onMove = (e: MouseEvent) => {
      setPos(clamp(
        dragStart.px + e.clientX - dragStart.mx,
        dragStart.py + e.clientY - dragStart.my,
      ));
    };
    const onUp = () => setDragging(false);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
  }, [dragging, dragStart, clamp]);

  // If the viewport shrinks (window resized), pull an undocked window back into
  // view so it can never end up parked off-frame.
  useEffect(() => {
    if (docked) return;
    const onResize = () => setPos(p => clamp(p.x, p.y));
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [docked, clamp]);

  if (!active || typeof document === "undefined") return null;

  const showSwitcher = shares.length > 1;
  const canStop = active.isLocal && !!onStopLocal;

  if (isFullscreen) {
    return createPortal(
      <div className="fixed inset-0 z-[80] bg-black flex flex-col">
        <div className="flex items-center justify-between px-4 py-2 bg-neutral-900/80 absolute top-0 left-0 right-0 z-10">
          <span className="text-white text-sm truncate">{active.userName} демонстрирует экран</span>
          <div className="flex gap-2">
            <button onClick={() => setIsFullscreen(false)}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs transition-colors">
              Выйти из полного экрана
            </button>
            {canStop && (
              <button onClick={onStopLocal}
                className="px-3 py-1.5 rounded-lg bg-red-500/80 hover:bg-red-500 text-white text-xs transition-colors">
                Остановить
              </button>
            )}
          </div>
        </div>
        <video ref={attachVideo} autoPlay muted playsInline className="w-full h-full object-contain" />
        {showSwitcher && (
          <SwitcherBar shares={shares} activeSocketId={active.socketId} onSelect={setActiveId} />
        )}
      </div>,
      document.body,
    );
  }

  // While minimised the window docks to the bottom-centre of the screen (it
  // becomes an audio/status bar). Otherwise it's centred when docked, or wherever
  // the user dragged it.
  //
  // Centring is done with `inset: 0` + `margin: auto` rather than a
  // `transform: translate(-50%, -50%)`. This is deliberate: the window is a
  // Framer Motion component that animates `scale`, and Framer writes the
  // element's `transform` from its own motion values — so any `transform` set
  // through `style` (like a centring translate) is silently overwritten once the
  // scale animation runs. That was the "off-centre / asymmetric" bug: the
  // translate was dropped, leaving the window pinned by its top-left corner at
  // the 50%/50% point (i.e. shoved into the bottom-right quadrant). Layout-based
  // centring (margin auto around a fixed size) is immune to the transform and
  // stays perfectly centred while the scale animation plays.
  const positionStyle: React.CSSProperties = minimized
    ? { left: 0, right: 0, bottom: 16, top: "auto", marginLeft: "auto", marginRight: "auto", zIndex: 9997 }
    : docked
      ? { inset: 0, margin: "auto", zIndex: 9997 }
      : { left: pos.x, top: pos.y, zIndex: 9997 };

  return createPortal(
    <motion.div
      ref={dragRef}
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.96 }}
      style={positionStyle}
      className={`fixed flex flex-col rounded-2xl overflow-hidden shadow-2xl border border-white/10 select-none
        ${minimized ? "w-72 h-auto cursor-default" : `${sizeClasses[size]} ${dragging ? "cursor-grabbing" : "cursor-grab"}`}`}
      onMouseDown={onMouseDown}
    >
      {/* Header bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-neutral-900/95 backdrop-blur-sm gap-2 flex-shrink-0">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse flex-shrink-0" />
          <span className="text-white text-xs truncate">{active.userName} демонстрирует экран</span>
          {showSwitcher && (
            <span className="text-[10px] text-white/40 flex-shrink-0">
              · {shares.length} экрана
            </span>
          )}
          {/* When minimised, show that the shared audio keeps playing. */}
          {minimized && (
            <svg className="w-3.5 h-3.5 text-green-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-label="Звук воспроизводится">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5L6 9H2v6h4l5 4V5z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14" />
            </svg>
          )}
        </div>

        <div className="flex items-center gap-1 flex-shrink-0">
          {/* Size controls */}
          {!minimized && (
            <>
              {(["sm", "md", "lg"] as const).map(s => (
                <button key={s} onClick={e => { e.stopPropagation(); setSize(s); }}
                  className={`px-1.5 py-0.5 rounded text-[10px] transition-colors ${
                    size === s
                      ? "bg-white/20 text-white"
                      : "text-white/50 hover:text-white hover:bg-white/10"
                  }`}>
                  {s === "sm" ? "S" : s === "md" ? "M" : "L"}
                </button>
              ))}
              <button onClick={e => { e.stopPropagation(); setIsFullscreen(true); }}
                className="p-1 text-white/50 hover:text-white hover:bg-white/10 rounded transition-colors" title="На весь экран">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                </svg>
              </button>
            </>
          )}

          <button onClick={e => { e.stopPropagation(); setMinimized(m => !m); }}
            className="p-1 text-white/50 hover:text-white hover:bg-white/10 rounded transition-colors"
            title={minimized ? "Развернуть" : "Свернуть"}>
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={minimized ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} />
            </svg>
          </button>

          {canStop && (
            <button onClick={e => { e.stopPropagation(); onStopLocal?.(); }}
              className="px-2 py-0.5 rounded bg-red-500/80 hover:bg-red-500 text-white text-[10px] transition-colors">
              Стоп
            </button>
          )}
        </div>
      </div>

      {/* Video — fills the remaining space of the stage */}
      {!minimized && (
        <video
          ref={attachVideo}
          autoPlay muted playsInline
          className="flex-1 w-full min-h-0 object-contain bg-black"
        />
      )}

      {/* Participant switcher (only with more than one share) */}
      {!minimized && showSwitcher && (
        <SwitcherBar shares={shares} activeSocketId={active.socketId} onSelect={setActiveId} compact={size === "sm"} />
      )}
    </motion.div>,
    document.body,
  );
}

/* ── Participant switcher: a Discord-style strip of live thumbnails ── */
function SwitcherBar({ shares, activeSocketId, onSelect, compact = false }: {
  shares: ScreenShare[];
  activeSocketId: string;
  onSelect: (socketId: string) => void;
  compact?: boolean;
}) {
  return (
    <div className={`flex items-center gap-2 overflow-x-auto flex-shrink-0 ${compact ? "px-3 py-1.5" : "px-3 py-2"} bg-neutral-900/90 border-t border-white/10`}>
      {shares.map(s => (
        <ShareThumb
          key={s.socketId}
          share={s}
          active={s.socketId === activeSocketId}
          onClick={() => onSelect(s.socketId)}
        />
      ))}
    </div>
  );
}

/* ── One live thumbnail in the participant switcher ── */
function ShareThumb({ share, active, onClick }: {
  share: ScreenShare;
  active: boolean;
  onClick: () => void;
}) {
  const attach = useCallback((el: HTMLVideoElement | null) => {
    if (el && el.srcObject !== share.stream) {
      el.srcObject = share.stream;
      el.play().catch(() => {});
    }
  }, [share.stream]);

  return (
    <button
      onClick={e => { e.stopPropagation(); onClick(); }}
      title={share.userName}
      className={`relative flex-shrink-0 w-28 h-16 rounded-lg overflow-hidden border transition-all ${
        active ? "border-green-400 ring-2 ring-green-400/40" : "border-white/10 hover:border-white/30 opacity-80 hover:opacity-100"
      }`}
    >
      <video ref={attach} autoPlay muted playsInline className="w-full h-full object-cover bg-black" />
      <span className="absolute bottom-0 left-0 right-0 px-1 py-0.5 text-[9px] text-white bg-black/60 truncate text-left">
        {share.userName}
      </span>
    </button>
  );
}

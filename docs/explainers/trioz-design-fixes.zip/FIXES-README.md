# TrioZ — исправления заметных (🔴) и средних (🟡) багов дизайна

Дата: 15.07.2026. Затронуто 14 файлов, все в `apps/web`.

## Как применить

Вариант 1 — патч (из корня монорепо):
```bash
git apply design-fixes.patch
# или без git:
patch -p1 < design-fixes.patch
```

Вариант 2 — просто скопировать файлы из папки `apps/` этого архива поверх проекта (структура путей сохранена).

---

## Заметные баги (B1–B6)

### B1. Лишний скроллбар на десктопе (spacer навбара + min-h-screen)
- `globals.css`: добавлена переменная `--tz-navbar-h: 64px`.
- `connect/page.tsx`: экраны загрузки и «не авторизован» теперь `min-h-[calc(100vh-var(--tz-navbar-h)-var(--tz-desktop-inset-bottom,0px))]` (на мобильных — `100dvh`), высота основного контейнера тоже переведена на переменную. Заодно закрыт мелкий баг B18 (магическое число 64px).
- Примечание: другие страницы с `min-h-screen` (вне /connect) я не трогал — там контент скроллится естественно; при желании их можно перевести на ту же переменную.

### B2. Обрезанный «пилюльный» индикатор активного пункта в рельсе NavRail
- `globals.css`: `.cn-nav-btn.active::before` — `left: -16px` → `left: -12px`, индикатор больше не срезается `overflow-hidden` рельсы.

### B3. Двойное монтирование мобильного и десктопного деревьев на /connect
- `connect/page.tsx`: добавлен хук на `matchMedia("(min-width: 768px)")`; мобильное дерево рендерится только при `isDesktopViewport !== true`, десктопное — при `!== false`. SSR/гидратация не ломаются (до первого эффекта рендерятся обе ветки, как раньше, CSS их скрывает). Итог: `MessageArea` живёт в DOM один раз — нет двойных сокет-подписок и дублирующихся запросов.

### B4. Дропдаун пользователя в навбаре мерцает и недоступен с клавиатуры
- `Navbar.tsx`: зазор `mt-1` заменён на `pt-1` внутри позиционируемой обёртки — курсор больше не «проваливается» между кнопкой и меню; добавлен `group-focus-within:*` — меню открывается по Tab/фокусу.

### B5. Недостаточный контраст `--cn-muted` в тёмной Cyber-теме
- `globals.css`: `#4a5568` → `#8b93a3` (контраст на фоне `#0f0f17`/`#12121c` ≈ 4.9:1, проходит WCAG AA; раньше было ~3.2:1).

### B6. Вспышка веб-навигации в Electron-оболочке
- `layout.tsx`: анти-flash-скрипт в `<head>` теперь помечает `<html class="tz-desktop">` (по `window.triozDesktop` или UA Electron) до первой отрисовки.
- `globals.css` + `Navbar.tsx`: классы `tz-web-only`, `tz-navbar-inner`, `tz-navbar-right` скрывают веб-ссылки и раскладывают контролы мгновенно через CSS, не дожидаясь `useEffect`.

## Средние проблемы (B7–B12)

### B7. Пересечение брейкпоинтов ровно на 768px
- `globals.css`: кастомный `@media (max-width: 768px)` → `(max-width: 767.98px)` — больше не конфликтует с Tailwind `md:` (min-width: 768px).

### B8. Hover-тулбар сообщения обрезается у верхнего края
- `MessageArea.tsx`: скролл-контейнер `p-4` → `px-4 pb-4 pt-5` — тулбару первого сообщения (top: −14px) гарантирован запас сверху.

### B9. PanelResizer: только мышь + жёсткий сброс на 240
- `PanelResizer.tsx`: переписан на Pointer Events + `setPointerCapture` — работает на сенсорных экранах и стилусах; `touch-action: none`. Сброс по двойному клику — новый проп `resetWidth` (по умолчанию 240), значение клампится в `[min, max]`.

### B10. Хаотичная шкала z-index (9998/9999/200/100)
- Введена шкала (задокументирована в конце `globals.css`): 40 плавающие элементы · 50 навбар/дропдауны · 60 модалки · 70 вложенные модалки · 80 полноэкранная демонстрация · 85 мини-профиль · 90 лайтбокс/сплэш · 95 системные индикаторы.
- Изменены: `ConnectSplash` 9999→90, `ImageLightbox` 9999→90, `InlineEditOverlay` 9999→95, `MiniProfile` 9999→85, `ScreenShareWindow` 9998→80, `WelcomeModal` 9999→70, страница игры Velderan 100→40 и 200→70. Порядок наложения внутри каждой связки сохранён. (Бар Electron 2147483647 не трогал — он вне DOM страницы.)

### B11. Сдвиг контента при появлении полосы прокрутки
- `globals.css`: `scrollbar-gutter: stable` для `html` на десктопе (≥768px).

### B12. Нет видимого фокуса для клавиатурной навигации
- `globals.css`: `:focus-visible` (outline акцентным цветом) для `.cn-nav-btn`, `.cn-channel-btn`, кнопок тулбара сообщений.
- `ChannelSidebar.tsx`: скрытые до ховера кнопки (создание/удаление каналов, mute, и т.п.) получили `focus-visible:opacity-100` / `focus-within:opacity-100` — доступны с клавиатуры.
- `Navbar.tsx`: меню пользователя открывается по фокусу (см. B4).

---

## Изменённые файлы

```
apps/web/src/app/globals.css
apps/web/src/app/layout.tsx
apps/web/src/app/connect/page.tsx
apps/web/src/app/games/velderan/play/[id]/page.tsx
apps/web/src/components/ui/Navbar.tsx
apps/web/src/components/ui/ImageLightbox.tsx
apps/web/src/components/ui/MiniProfile.tsx
apps/web/src/components/InlineEditOverlay.tsx
apps/web/src/components/WelcomeModal.tsx
apps/web/src/components/connect/MessageArea.tsx
apps/web/src/components/connect/PanelResizer.tsx
apps/web/src/components/connect/ChannelSidebar.tsx
apps/web/src/components/connect/ConnectSplash.tsx
apps/web/src/components/voice/ScreenShareWindow.tsx
```

## Что проверить после применения

1. `/connect` на десктопе: нет вертикального скроллбара на экранах загрузки/логина; активный пункт рельсы с целой «пилюлей»; в DevTools только одно дерево (мобильное ИЛИ десктопное).
2. Навбар: меню пользователя не мерцает при наведении, открывается по Tab.
3. Electron: при запуске нет вспышки веб-ссылок.
4. Перетаскивание границы списка каналов пальцем на сенсорном экране; двойной клик — сброс ширины.
5. Tab-навигация: видимая рамка фокуса на кнопках рельсы/каналов, скрытые кнопки появляются при фокусе.
6. Оверлеи: лайтбокс поверх модалок, мини-профиль поверх демонстрации экрана.
